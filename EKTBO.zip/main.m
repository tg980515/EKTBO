
addpath(genpath(pwd));
maxRuns =19;
BI_list = [];
j(1)=10;
j(2)=20;

BI_list = [BI_list;getBLOPinfo('SMD',1,10)];
% BI_list = [getBiTEA('BSMD',1:6,12)];8
% BI_list = [BI_list;getBLOPinfo('TP',1:10)];
% BI_list = [BI_list;getBLOPinfo('SMD',1:12,10)];
% BI_list = [BI_list;getBLOPinfo('SMD',1:12,20)];

% BI_list = [BI_list;getBLOPinfo('GoldMining')];
% BI_list = [BI_list;getBLOPinfo('DecisionMaking)];

% BI_list = [BI_list;getBLOPinfo('TP',1:10)];
% BI_list = [BI_list;getBLOPinfo('SMD',9:12,5)];
% BI_list = [BI_list;getBLOPinfo('TP',10)];
res_uacc=[];
res_lacc=[];
res_ufes=[];
res_lfes=[];
IQR_uacc=[];
IQR_lacc=[];
IQR_ufes=[];
IQR_lfes=[];
algName = 'EKTBO';

for BI = BI_list'
    if BI.dim == 3
        % for gold mining problem
        BI.UmaxFEs = 1500;
        BI.UmaxImprFEs = 70;
        BI.LmaxFEs = 150;
        BI.LmaxImprFEs = 15;
        BI.delta=0;
    elseif BI.dim == 5 || BI.dim == 6 
        % for generic benchmark test problem or decision making problem 
        BI.UmaxFEs = 2500;
        BI.UmaxImprFEs = 350;
        BI.LmaxFEs = 250;
        BI.LmaxImprFEs = 25;
        BI.delta=3;
    elseif BI.dim == 10
        BI.UmaxFEs = 3500;
        BI.UmaxImprFEs = 500;
        BI.LmaxFEs = 350;
        BI.LmaxImprFEs = 35;
        BI.delta=2;
    elseif BI.dim == 20
        BI.UmaxFEs = 5000;
        BI.UmaxImprFEs = 750;
        BI.LmaxFEs = 500;
        BI.LmaxImprFEs = 50;
        BI.delta=2;
    elseif BI.dim == 12
        BI.UmaxFEs = 3500;
        BI.UmaxImprFEs = 500;
        BI.LmaxFEs = 350;
        BI.LmaxImprFEs = 35;
        BI.delta=0;
    elseif strcmp(BI.fn(1:2),'tp')
          BI.UmaxFEs = 2500;
        BI.UmaxImprFEs = 350;
        BI.LmaxFEs = 250;
        BI.LmaxImprFEs = 25;
        BI.delta=300;
    else
        error('unknown dimensionality');
    end
    
    BI.u_N = 50;
    BI.l_N = 50;

% 	parfor runNo = 1:maxRuns
    x1=[];x2=[];x3=[];x4=[];x5=[];x6=[];x7=[];
    p1=[];p2=[];p3=[];p4=[];p5=[];p6=[];p7=[];
    time=[];

    for runNo = 1:maxRuns
		tic;
 		ins = EKTBO(BI);
%         ins =EKTBO(BI);
%         ins2=BLEA(BI);
%         ins3=TLEA(BI);
		ins.runPath = pwd;
		ins.runNo = runNo;
		ins.BI = BI;
		ins.alg = algName;
		ins.runTime = toc;
        fprintf('%s %s #%d [%g,%g,%d,%d] \n', ins.alg, ins.BI.fn, ins.runNo, ins.UF, ins.LF,ins.UFEs,ins.LFEs);
        x1=[x1;ins.alg];
        x2=[x2;ins.BI.fn];
        x3=[x3;ins.runNo];
        x4=[x4;ins.UF];
        x5=[x5;ins.LF];
        x6=[x6;ins.UFEs];
        x7=[x7;ins.LFEs];
        time=[time;ins.runTime];
 
% 
%         ins_2=TLEA (BI);
%         ins_2.runPath = pwd;
% 		ins_2.runNo = runNo;
% 		ins_2.BI = BI;
% 		ins_2.alg = algName;
% 		ins_2.runTime = toc;
%          p1=[p1;ins_2.alg];
%         p2=[p2;ins_2.BI.fn];
%         p3=[p3;ins_2.runNo];
%         p4=[p4;ins_2.UF];
%         p5=[p5;ins_2.LF];
%         p6=[p6;ins_2.UFEs];        
%         p7=[p7;ins_2.LFEs];
%          ins1 = wapper(BI);
        


   end
%     disp('UACC_P_value');disp(ranksum(x4,p4));
%     disp('LACC_P_value');disp(ranksum(x5,p5));
%     disp('UFES_P_value');disp(ranksum(x6,p6));
%     disp('LFES_P_value');disp(ranksum(x7,p7));
%     disp('UFES_LFES_P_VALUE');disp(ranksum(x6+x7,p6+p7));
% 
% EGTBO_fit=abs([ins.record.fit]);
% TLEACMAES_fit=abs([ins_2.record.fit]);
% 
% EGTBO_LFES=[ins.record.LFEs];
% EGTBO_UFES=[ins.record.UFEs];
% EGTBO_TFES=EGTBO_LFES+EGTBO_UFES;
% 
% 
% TLEA_LFES=[ins_2.record.LFEs];
% TLEA_UFES=[ins_2.record.UFEs];
% TLEACMAES_TFES=TLEA_LFES+TLEA_UFES;
% 
% 
% figure; % 创建一个新的图形窗口
% plot(EGTBO_TFES, EGTBO_fit, 'b-o', 'LineWidth', 2, 'DisplayName', 'EGTBO'); % 绘制TLEACMAES的折线图
% hold on; % 保持当前图形，以便在同一图上绘制另一条线
% plot(TLEACMAES_TFES, TLEACMAES_fit, 'r-s', 'LineWidth', 2, 'DisplayName', 'EKTBO'); % 绘制EKSBO的折线图
% 
% % 添加图例
% legend('show');
% 
% % 添加标题和轴标签
% title('Convergence Behavior');
% xlabel('TFEs'); % 假设x轴表示的是FE乘以10的4次方
% ylabel('UACC');
% % 设置x轴的刻度格式为科学计数法
% xtickformat('%.1e');
% ytickformat('%.1e');
% % 调整图形的显示范围
% % xlim([0.2, 2]); % x轴的显示范围
% % ylim([0, 1]); % y轴的显示范围
% 
% % 显示网格
% grid on;


[~,index]=sort(x4);
[~,ll_index]=sort(x5);
[~,u_index]=sort(x6);
[~,l_index]=sort(x7);
dim=num2str(ins.BI.dim);
UACC_median=median(x4);
LACC_median=median(x5);
UACC_IQR=iqr(x4);
LACC_IQR=iqr(x5);
UACC_metric=[UACC_median,UACC_IQR];
LACC_metric=[LACC_median,LACC_IQR];
UFEs_median=median(x6);
UFEs_IQR=round(iqr(x6));
LFEs_median=median(x7);
LFEs_IQR=round(iqr(x7));
UFEs_metric=[UFEs_median,UFEs_IQR];
LFEs_metric=[LFEs_median,LFEs_IQR];
meanruntime=mean(time);
% filename='UACC.mat';
% save(['D:\EKTBO\data\SMD\', ins.BI.fn,'_',dim,'_','dim','_',ins.alg,'_',filename], 'x4');
% filename='LACC.mat';
% save(['D:\EKTBO\data\SMD\', ins.BI.fn,'_',dim,'_','dim','_',ins.alg,'_',filename], 'x5');
% filename='UFEs.mat';
% save(['D:\EKTBO\data\SMD\', ins.BI.fn,'_',dim,'_','dim','_',ins.alg,'_',filename], 'x6');
% filename='LFEs.mat';
% save(['D:\EKTBO\data\SMD\', ins.BI.fn,'_',dim,'_','dim','_',ins.alg,'_',filename], 'x7');
% filename='Runtime.mat';
% save(['D:\EKTBO\data\SMD\', ins.BI.fn,'_',dim,'_','dim','_',ins.alg,'_',filename], 'time');
% 
% filename='UACC_metric.mat';
% save(['D:\EKTBO\data\SMD\', ins.BI.fn,'_',dim,'_','dim','_',ins.alg,'_',filename], 'UACC_metric');
% filename='LACC_metric.mat';
% save(['D:\EKTBO\data\SMD\', ins.BI.fn,'_',dim,'_','dim','_',ins.alg,'_',filename], 'LACC_metric');
% filename='UFEs_metric.mat';
% save(['D:\EKTBO\data\SMD\', ins.BI.fn,'_',dim,'_','dim','_',ins.alg,'_',filename], 'UFEs_metric');
% filename='LFEs_metric.mat';
% save(['D:\EKTBO\data\SMD\', ins.BI.fn,'_',dim,'_','dim','_',ins.alg,'_',filename], 'LFEs_metric');
% filename='MeanRuntime.mat';
% save(['D:\EKTBO\data\SMD\', ins.BI.fn,'_',dim,'_','dim','_',ins.alg,'_',filename], 'meanruntime');
% % disp('ITLEA');
disp('UACC_res');disp(UACC_median);
disp('LACC_res');disp(LACC_median);
disp('upper_fes');disp(UFEs_median);
disp('lower_fes');disp(LFEs_median);
disp('UACC_IQR_value');disp(UACC_IQR);
% 
% % % % 
disp('LACC_IQR_value');disp(LACC_IQR);
disp('UFEs_IQR_value');disp(UFEs_IQR);
disp('LFEs_IQR_value');disp(LFEs_IQR);
disp('Meanruntime:'); disp(meanruntime);
% res_uacc=[res_uacc;x4(index(10))];
% res_lacc=[res_lacc;x5(index(10))];
% res_ufes=[res_ufes;x6(u_index(10))];
% res_lfes=[res_lfes;x7(l_index(10))];
% IQR_uacc=[IQR_uacc;x4(index(5))-x4(index(15))];
% IQR_lacc=[IQR_lacc;x5(ll_index(5))-x5(ll_index(15))];
% IQR_ufes=[IQR_ufes;x6(u_index(5))-x6(u_index(15))];
% IQR_lfes=[IQR_lfes;x7(l_index(5))-x7(l_index(15))];
%      xlswrite('tempdata',x1,'ins.alg');
%      xlswrite('tempdata',x2,'ins.BI.fn');
%      xlswrite('tempdata',x3,'ins.runNo');
%      xlswrite('tempdata',x4,'ins.UF');
%      xlswrite('tempdata',x5,'ins.LF'); 
%      xlswrite('tempdata',x6,'ins.UFEs');
%      xlswrite('tempdata',x7,'ins.LFEs'); 
end
                                          
function ins = wapper(BI)
[ins.UF,ins.LF,ins.UX,ins.LX,ins.UFEs,ins.LFEs,ins.record]=ulSearch(BI.fn, ...
BI.u_N, BI.u_maxGen, ...
BI.u_dim, BI.u_lb, BI.u_ub, ...
BI.l_N, BI.l_maxGen, ...
BI.l_dim, BI.l_lb, BI.l_ub, ...
BI.ulStoppingCriteria, BI.llStoppingCriteria);
end

