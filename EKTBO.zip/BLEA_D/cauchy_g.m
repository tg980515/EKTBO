function p = cauchy_g(mu, gamma)
    p= mu + gamma * tan(pi*(rand - 0.5));
end