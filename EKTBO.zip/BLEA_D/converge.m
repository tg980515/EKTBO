% 创建示例数据
x1 = [ins.record.UFEs]+[ins.record.LFEs];
x2=[ins2.record.UFEs]+[ins2.record.LFEs];
x3=[ins3.record.UFEs]+[ins3.record.LFEs];
y1 = abs([ins.record.LF]);
y2 = abs([ins2.record.LF]);
y3 = abs([ins3.record.LF]);

% 创建折线图
plot(x1, y1, 'DisplayName', 'Elite knowledge sharing strategy');
hold on;
plot(x2, y2, 'DisplayName', 'BLCMAES');
plot(x3, y3, 'DisplayName', 'TLEA');
hold off;

% 设置图例
legend('show');

% 设置横轴和纵轴刻度为科学计数法
set(gca, 'XScale', 'log');
set(gca, 'YScale', 'log');

% 添加标题和标签
title('Scientific Notation Line Plot');
xlabel('X-axis');
ylabel('Y-axis');